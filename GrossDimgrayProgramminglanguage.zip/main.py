print("Hello World")
age=25
age+=1
print(age)

def square(x):
  return x*x

for i in range(10):
  print(f"{i} square is {square(i)}")

print("Square of 25 is ",square(25))

costInp = int(input("Please enter the cost ", ))
print(costInp)
discountInp = int(input ("please enter the discount ", ))
print(discountInp)

discount = costInp-costInp*discountInp/100
print(discount)
taxInp=5
tax=taxInp+taxInp*discount/100
print(tax)
total= 5+tax
print(total)
if total > 10:
  print ("You get free shipping")
else:
  print("spend 10 for get free shipping")

print("*"*20)
print("Twinkle twinkle little star \n\t how i wonder what you are \n\t\t up above the world so high \n\t\t like a diamond in the sky \n\t when the blazing sun is gone \n When nothing shines upon")
print("*"*20)
  
var = str(input( ))
if(var.find('emergency') != -1):
  print("Yes")
else:
  print("no")

accAmount = int(input("Please enter your account balance ", ))
if accAmount > 0:
  print("You've got money baby")
elif accAmount < 0:
  print("You're in debt bro, condolences for you")
else:
  print("you're officially broke now")





  
